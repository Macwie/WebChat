CREATE PROCEDURE films_getFilm(IN `_filmId` INT)
  BEGIN
	DECLARE StatusCode CHAR(5) DEFAULT '00000';
	DECLARE Message TEXT;

	IF NOT EXISTS(SELECT 1 FROM Film WHERE filmId = _filmId) THEN
    BEGIN
      SET StatusCode = '102';
      SET Message = 'FILM NOT EXIST';
    END;
  END IF;

  IF (StatusCode = '00000') THEN
    BEGIN
  		COMMIT;
  		SELECT filmId, title, year, Country, Director, Image, Type FROM Film WHERE filmId = _filmId;
	   END;
	ELSE
    BEGIN
  		ROLLBACK;
  		SELECT StatusCode, Message;
	  END;
  END IF;

END;
