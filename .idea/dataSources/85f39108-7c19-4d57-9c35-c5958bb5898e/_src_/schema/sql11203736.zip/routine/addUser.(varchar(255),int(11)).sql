CREATE PROCEDURE addUser(IN `_nick` VARCHAR(255), IN `_pin` INT)
  BEGIN
	DECLARE StatusCode CHAR(5) DEFAULT '00000';
	DECLARE Message TEXT;

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION

	START TRANSACTION;
	IF EXISTS(SELECT 1 FROM Location WHERE nick = _nick) THEN
		BEGIN
			SET StatusCode = '102';
			SET Message = 'USER EXISTS';
		END;
	ELSE
		BEGIN
			INSERT INTO Location (nick,pin) VALUES (_nick,_pin);
		END;
	END IF;

    IF (StatusCode = '00000') THEN
    BEGIN
    SET StatusCode = '100';
    SET Message = 'USER CREATED';
		COMMIT;
		SELECT StatusCode, Message;
	END;
	ELSE
    BEGIN
		ROLLBACK;
		SELECT StatusCode, Message;
	END;
    END IF;

END;
