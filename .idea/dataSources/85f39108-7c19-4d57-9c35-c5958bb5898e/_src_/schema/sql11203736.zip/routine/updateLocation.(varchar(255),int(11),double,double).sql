CREATE PROCEDURE updateLocation(IN `_nick` VARCHAR(255), IN `_pin` INT, IN `_latitude` DOUBLE, IN `_longitude` DOUBLE)
  BEGIN
	DECLARE StatusCode CHAR(5) DEFAULT '00000';
	DECLARE Message TEXT;
	DECLARE currDate datetime;

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION


	START TRANSACTION;
	IF EXISTS(SELECT 1 FROM Location WHERE nick = _nick AND pin = _pin) THEN
		BEGIN
		SELECT CURRENT_TIMESTAMP into currDate;
			UPDATE Location SET latitude = _latitude, longitude = _longitude, date = currDate WHERE nick = _nick AND pin = _pin;
		END;
	ELSE
		BEGIN
			SET StatusCode = '244';
			SET Message = 'WRONG NAME OR PIN';
		END;
    END IF;

  IF (StatusCode = '00000') THEN
    BEGIN
		SET StatusCode = '800';
		SET Message = 'LOCATION UPDATED';
		COMMIT;
		SELECT StatusCode, Message, currDate;
	END;
	ELSE
    BEGIN
		ROLLBACK;
		SELECT StatusCode, Message;
	END;
    END IF;

END;
