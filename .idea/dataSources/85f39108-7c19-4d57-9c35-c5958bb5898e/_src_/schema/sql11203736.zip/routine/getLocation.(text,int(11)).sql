CREATE PROCEDURE getLocation(IN `_nick` TEXT, IN `_pin` INT)
  BEGIN
	DECLARE StatusCode CHAR(5) DEFAULT '00000';
	DECLARE Message TEXT;
	DECLARE currDate datetime;
	DECLARE minutes INT;
    DECLARE usDate datetime;

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
	START TRANSACTION;

	SELECT CURRENT_TIMESTAMP into currDate;
	SELECT date FROM Location WHERE nick = _nick AND pin = _pin into usDate;
    SELECT TIMESTAMPDIFF(MINUTE,usDate,currDate)into minutes;
	
	
	IF NOT EXISTS(SELECT 1 FROM Location WHERE nick = _nick AND pin = _pin) THEN
    BEGIN
      SET StatusCode = '802';
      SET Message = 'USER NOT EXISTS';
    END;
	ELSEIF (minutes >= 1) THEN
	BEGIN
      SET StatusCode = '997';
      SET Message = 'PROBABLY OFFLINE';
    END;
	END IF;

  IF (StatusCode = '00000') THEN
    BEGIN
  		COMMIT;
  		SELECT latitude, longitude FROM Location WHERE nick = _nick AND pin = _pin;
	   END;
	ELSE
    BEGIN
  		ROLLBACK;
  		SELECT StatusCode, Message;
	  END;
  END IF;
END;
