CREATE PROCEDURE films_getFilms()
  BEGIN
	DECLARE StatusCode CHAR(5) DEFAULT '00000';
	DECLARE Message TEXT;
  SELECT filmId, title, year, Country, Director, Image, Type FROM Film;

END;
